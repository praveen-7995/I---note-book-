# Backend for i-Notebook ([Client Repository](https://github.com/ayushyadav9/inote-client))

API: [https://inotes-backend.herokuapp.com](https://inotes-backend.herokuapp.com/)
